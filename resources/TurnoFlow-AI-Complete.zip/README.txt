# TurnoFlow AI — Kit de Implementación Oficial
Versión: 1.0.0
Fecha de Emisión: 2026-11-07T21:35:36.715Z
Licencia: Comercial (Pago Único USD 49)

## Contenido del Paquete:
1. /documentation: 13 Guías completas paso a paso (desde START-HERE.md hasta resolución de errores).
2. /automations: 5 Workflows oficiales para n8n en formato JSON listo para importar.
3. /prompts: 5 Especificaciones blindadas de prompts para los Agentes Especializados.
4. /templates: 5 Archivos CSV modelo (servicios, configuración, FAQs, leads y turnos).
5. /resources: Checklists de pre-instalación, puesta en marcha, seguridad y biblioteca de mensajes.

Para comenzar, abre:
documentation/START-HERE.md
